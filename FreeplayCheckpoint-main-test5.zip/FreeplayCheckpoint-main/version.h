
#pragma once
#define VERSION_MAJOR 1
#define VERSION_MINOR 8
#define VERSION_PATCH 1
#define VERSION_BUILD 740

#define stringify(a) stringify_(a)
#define stringify_(a) #a

